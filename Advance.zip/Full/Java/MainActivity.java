package com.gcq.postmanagerapp;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;

import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {


    private EditText courseNameEdt, courseDurationEdt, courseDescriptionEdt, courseTracksEdt;
    private Button addBtn, updateBtn, deleteBtn,displayBtn,Nextbtn,btnurl;
    private ListView courseListView;
    private DBHandler dbHandler;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        courseNameEdt = findViewById(R.id.idEdtCourseName);
        courseDurationEdt = findViewById(R.id.idEdtCourseDuration);
        courseDescriptionEdt = findViewById(R.id.idEdtCourseDescription);
        courseTracksEdt = findViewById(R.id.idEdtCourseTracks);
        addBtn = findViewById(R.id.idBtnAdd);
        updateBtn = findViewById(R.id.idBtnUpdate);
        deleteBtn = findViewById(R.id.idBtnDelete);
        displayBtn=findViewById(R.id.idBtnDisplay);
        courseListView = findViewById(R.id.idListView);
        Nextbtn=findViewById(R.id.idNext);
        btnurl = findViewById(R.id.idurl);


        dbHandler = new DBHandler(MainActivity.this);

        // *Add Course*
        addBtn.setOnClickListener(v -> {
            dbHandler.addCourse(
                    courseNameEdt.getText().toString(),
                    courseDurationEdt.getText().toString(),
                    courseDescriptionEdt.getText().toString(),
                    courseTracksEdt.getText().toString()
            );
            Toast.makeText(this, "Course Added", Toast.LENGTH_SHORT).show();

        });

        // *Update Course*
        updateBtn.setOnClickListener(v -> {
            dbHandler.updateCourse(
                    courseNameEdt.getText().toString(),
                    courseNameEdt.getText().toString(),
                    courseDurationEdt.getText().toString(),
                    courseDescriptionEdt.getText().toString(),
                    courseTracksEdt.getText().toString()
            );
            Toast.makeText(this, "Course Updated", Toast.LENGTH_SHORT).show();
        });

        // *Delete Course*
        deleteBtn.setOnClickListener(v -> {
            dbHandler.deleteCourse(courseNameEdt.getText().toString());
            Toast.makeText(this, "Course Deleted", Toast.LENGTH_SHORT).show();
        });

        displayBtn.setOnClickListener(v -> {
            // Display Courses
            displayCourses();
        });
//explicit intent
        Nextbtn.setOnClickListener(View ->{
            Intent intent = new Intent(this,Nxtpage.class);
            startActivity(intent);
        });
//implicit intent
        btnurl.setOnClickListener(View ->{
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://google.com"));
            startActivity(intent);
        });
    }

    private void displayCourses() {
        ArrayList<String> courseList = dbHandler.getAllCourses();
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, courseList);
        courseListView.setAdapter(adapter);
    }
}