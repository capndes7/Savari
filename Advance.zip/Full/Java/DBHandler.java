package com.gcq.postmanagerapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import java.util.ArrayList;

public class DBHandler extends SQLiteOpenHelper {

    private static final String DB_NAME = "coursedb";
    private static final int DB_VERSION = 1;
    private static final String TABLE_NAME = "courses";

    private static final String ID_COL = "id";
    private static final String NAME_COL = "name";
    private static final String DURATION_COL = "duration";
    private static final String DESCRIPTION_COL = "description";
    private static final String TRACKS_COL = "tracks";

    public DBHandler(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String query = "CREATE TABLE " + TABLE_NAME + " ("
                + ID_COL + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + NAME_COL + " TEXT,"
                + DURATION_COL + " TEXT,"
                + DESCRIPTION_COL + " TEXT,"
                + TRACKS_COL + " TEXT)";
        db.execSQL(query);
    }

    // *1. Insert Data*
    public void addCourse(String name, String duration, String description, String tracks) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(NAME_COL, name);
        values.put(DURATION_COL, duration);
        values.put(DESCRIPTION_COL, description);
        values.put(TRACKS_COL, tracks);
        db.insert(TABLE_NAME, null, values);
        db.close();
    }

    // *2. Retrieve Data*
    public ArrayList<String> getAllCourses() {
        ArrayList<String> courseList = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_NAME, null);

        while (cursor.moveToNext()) {
            String course = "ID: " + cursor.getInt(0) +
                    "\nName: " + cursor.getString(1) +
                    "\nDuration: " + cursor.getString(2) +
                    "\nDescription: " + cursor.getString(3) +
                    "\nTracks: " + cursor.getString(4);
            courseList.add(course);
        }
        cursor.close();
        db.close();
        return courseList;
    }

    // *3. Update Data*
    public void updateCourse(String originalName, String newName, String newDuration, String newDescription, String newTracks) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(NAME_COL, newName);
        values.put(DURATION_COL, newDuration);
        values.put(DESCRIPTION_COL, newDescription);
        values.put(TRACKS_COL, newTracks);
        db.update(TABLE_NAME, values, NAME_COL + " = ?", new String[]{originalName});
        db.close();
    }

    // *4. Delete Data*
    public void deleteCourse(String courseName) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_NAME, NAME_COL + " = ?", new String[]{courseName});
        db.close();
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(db);
    }
}